File 1: main.cc
    Purpose: Accepts the arguments from the command line, calls the actual Calculator funtions

File 2: Calculator.h
    Purpose: Contains the function prototypes that use the arguments supplied to main to calculate the result

File 3: Calculator.cc
    Purpose: Uses the arguments supplied to main to calculate the result

File 4: makefile
    Purpose: Compiles the output file calculate when given the command make is given, cleans out intermediary files when given the command make clean